# Modern-C
&lt;Modern C> of Jens Gustedt, code for challenge problems
